<?php

define('EMAIL','shamubughacks20@gmail.com');
define('PASSWORD','Bughacks#2020');

define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS', '');
define('DB_NAME','email-verification');